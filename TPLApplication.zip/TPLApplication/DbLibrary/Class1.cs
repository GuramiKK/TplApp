﻿using System;

namespace DbLibrary
{
    public class Class1
    {
    }
}
