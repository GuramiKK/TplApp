﻿using System;
using System.Collections.Generic;

namespace DbLibrary.Models
{
    public partial class Tpls
    {
        public long TplId { get; set; }
        public long CarId { get; set; }
        public long PersonId { get; set; }
        public long CompanyId { get; set; }
        public long StatusId { get; set; }
        public byte[] TplPhoto { get; set; }
        public long TplLimitId { get; set; }
    }
}
