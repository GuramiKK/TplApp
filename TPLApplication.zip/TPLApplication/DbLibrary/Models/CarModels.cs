﻿using System;
using System.Collections.Generic;

namespace DbLibrary.Models
{
    public partial class CarModels
    {
        public long CarModelId { get; set; }
        public long CarManufactureId { get; set; }
        public string CarModelName { get; set; }
    }
}
