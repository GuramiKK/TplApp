﻿using System;
using System.Collections.Generic;

namespace DbLibrary.Models
{
    public partial class Companyes
    {
        public long CompanyId { get; set; }
        public string CompanyName { get; set; }
    }
}
