﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DbLibrary.Models.XModels
{
    public class LimitModel
    {
        public long LimitId { get; set; }
        public long LimitCompanyId { get; set; }
        public long LimitCount { get; set; }
        public long LimitPremium { get; set; }

        public string name { get; set; }
    }
}
