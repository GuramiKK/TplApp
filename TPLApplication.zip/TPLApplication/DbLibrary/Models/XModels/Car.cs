﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DbLibrary.Models.XModels
{
    public class Car
    {
        public long CarId { get; set; }
        public long CarModelId { get; set; }
        public DateTime CarDate { get; set; }
        public string CarRegistyNumber { get; set; }
        public string CarManufacturerName { get; set; }
        public long CarManufactureId { get; set; }
        public string CarModelName { get; set; }
    }
}
