﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DbLibrary.Models.XModels
{
    public class TplModel
    {
        public long TplId { get; set; }
        public long CarId { get; set; }
        public long PersonId { get; set; }
        public long CompanyId { get; set; }
        public long StatusId { get; set; }
        public byte[] TplPhoto { get; set; }
        public long TplLimitId { get; set; }

        public string StatusName { get; set; }

        public string PersonFirstName { get; set; }
        public string PersonLastName { get; set; }
        public long PersonIdentity { get; set; }
        public DateTime PersonBirthDate { get; set; }
        public long PersonPhone { get; set; }
        public string PersonMailAddress { get; set; }

        public long LimitCount { get; set; }
        public long LimitPremium { get; set; }

        public long CarModelId { get; set; }
        public DateTime CarDate { get; set; }
        public string CarRegistyNumber { get; set; }
        public string CarManufacturerName { get; set; }
        public long CarManufactureId { get; set; }
        public string CarModelName { get; set; }
    }
}
