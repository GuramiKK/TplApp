﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

namespace DbLibrary.Models
{
    public partial class TplDBContext : DbContext
    {
        public TplDBContext()
        {
        }

        public TplDBContext(DbContextOptions<TplDBContext> options)
            : base(options)
        {
        }

        public virtual DbSet<CarManufacturers> CarManufacturers { get; set; }
        public virtual DbSet<CarModels> CarModels { get; set; }
        public virtual DbSet<Cars> Cars { get; set; }
        public virtual DbSet<Companyes> Companyes { get; set; }
        public virtual DbSet<Limits> Limits { get; set; }
        public virtual DbSet<Persons> Persons { get; set; }
        public virtual DbSet<Statuses> Statuses { get; set; }
        public virtual DbSet<Tpls> Tpls { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. See http://go.microsoft.com/fwlink/?LinkId=723263 for guidance on storing connection strings.
                optionsBuilder.UseSqlServer("Server=.;Database=TplDB;Trusted_Connection=True;");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<CarManufacturers>(entity =>
            {
                entity.HasKey(e => e.CarManufacturerId)
                    .HasName("PK_CarManufacturer");

                entity.Property(e => e.CarManufacturerId).HasColumnName("CarManufacturer_Id");

                entity.Property(e => e.CarManufacturerName)
                    .IsRequired()
                    .HasColumnName("CarManufacturer_Name")
                    .HasMaxLength(50);
            });

            modelBuilder.Entity<CarModels>(entity =>
            {
                entity.HasKey(e => e.CarModelId)
                    .HasName("PK_CarModel");

                entity.Property(e => e.CarModelId).HasColumnName("CarModel_Id");

                entity.Property(e => e.CarManufactureId).HasColumnName("CarManufacture_Id");

                entity.Property(e => e.CarModelName)
                    .IsRequired()
                    .HasColumnName("CarModel_Name")
                    .HasMaxLength(50);
            });

            modelBuilder.Entity<Cars>(entity =>
            {
                entity.HasKey(e => e.CarId)
                    .HasName("PK_Car");

                entity.Property(e => e.CarId).HasColumnName("Car_Id");

                entity.Property(e => e.CarDate)
                    .HasColumnName("Car_Date")
                    .HasColumnType("date");

                entity.Property(e => e.CarModelId).HasColumnName("CarModel_Id");

                entity.Property(e => e.CarRegistyNumber)
                    .IsRequired()
                    .HasColumnName("Car_RegistyNumber")
                    .HasMaxLength(50);
            });

            modelBuilder.Entity<Companyes>(entity =>
            {
                entity.HasKey(e => e.CompanyId);

                entity.Property(e => e.CompanyId).HasColumnName("Company_Id");

                entity.Property(e => e.CompanyName)
                    .IsRequired()
                    .HasColumnName("Company_Name")
                    .HasMaxLength(250);
            });

            modelBuilder.Entity<Limits>(entity =>
            {
                entity.HasKey(e => e.LimitId)
                    .HasName("PK_Limit");

                entity.Property(e => e.LimitId).HasColumnName("Limit_Id");

                entity.Property(e => e.LimitCompanyId).HasColumnName("limit_CompanyId");

                entity.Property(e => e.LimitCount).HasColumnName("limit_count");

                entity.Property(e => e.LimitPremium).HasColumnName("limit_Premium");
            });

            modelBuilder.Entity<Persons>(entity =>
            {
                entity.HasKey(e => e.PersonId);

                entity.Property(e => e.PersonId).HasColumnName("Person_Id");

                entity.Property(e => e.PersonBirthDate)
                    .HasColumnName("Person_BirthDate")
                    .HasColumnType("date");

                entity.Property(e => e.PersonFirstName)
                    .HasColumnName("Person_FirstName")
                    .HasMaxLength(250);

                entity.Property(e => e.PersonIdentity).HasColumnName("Person_Identity");

                entity.Property(e => e.PersonLastName)
                    .HasColumnName("Person_LastName")
                    .HasMaxLength(250);

                entity.Property(e => e.PersonMailAddress)
                    .HasColumnName("Person_MailAddress")
                    .HasMaxLength(250);

                entity.Property(e => e.PersonPhone).HasColumnName("Person_Phone");
            });

            modelBuilder.Entity<Statuses>(entity =>
            {
                entity.HasKey(e => e.StatusId)
                    .HasName("PK_Statuse");

                entity.Property(e => e.StatusId).HasColumnName("Status_Id");

                entity.Property(e => e.StatusName)
                    .IsRequired()
                    .HasColumnName("Status_Name")
                    .HasMaxLength(50);
            });

            modelBuilder.Entity<Tpls>(entity =>
            {
                entity.HasKey(e => e.TplId)
                    .HasName("PK_TPL");

                entity.ToTable("TPLs");

                entity.Property(e => e.TplId).HasColumnName("TPL_Id");

                entity.Property(e => e.CarId).HasColumnName("Car_Id");

                entity.Property(e => e.CompanyId).HasColumnName("Company_Id");

                entity.Property(e => e.PersonId).HasColumnName("Person_Id");

                entity.Property(e => e.StatusId).HasColumnName("Status_Id");

                entity.Property(e => e.TplLimitId).HasColumnName("TPL_LimitId");

                entity.Property(e => e.TplPhoto)
                    .IsRequired()
                    .HasColumnName("TPL_Photo")
                    .HasMaxLength(2048);
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
