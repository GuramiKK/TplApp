﻿using System;
using System.Collections.Generic;

namespace DbLibrary.Models
{
    public partial class Limits
    {
        public long LimitId { get; set; }
        public long LimitCompanyId { get; set; }
        public long LimitCount { get; set; }
        public long LimitPremium { get; set; }
    }
}
