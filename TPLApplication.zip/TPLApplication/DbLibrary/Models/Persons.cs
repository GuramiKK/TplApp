﻿using System;
using System.Collections.Generic;

namespace DbLibrary.Models
{
    public partial class Persons
    {
        public long PersonId { get; set; }
        public string PersonFirstName { get; set; }
        public string PersonLastName { get; set; }
        public long PersonIdentity { get; set; }
        public DateTime PersonBirthDate { get; set; }
        public long PersonPhone { get; set; }
        public string PersonMailAddress { get; set; }
    }
}
