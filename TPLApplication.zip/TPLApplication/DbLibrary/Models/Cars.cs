﻿using System;
using System.Collections.Generic;

namespace DbLibrary.Models
{
    public partial class Cars
    {
        public long CarId { get; set; }
        public long CarModelId { get; set; }
        public DateTime CarDate { get; set; }
        public string CarRegistyNumber { get; set; }
    }
}
