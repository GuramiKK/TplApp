﻿using System;
using System.Collections.Generic;

namespace DbLibrary.Models
{
    public partial class CarManufacturers
    {
        public long CarManufacturerId { get; set; }
        public string CarManufacturerName { get; set; }
    }
}
