﻿using System;
using System.Collections.Generic;

namespace DbLibrary.Models
{
    public partial class Statuses
    {
        public long StatusId { get; set; }
        public string StatusName { get; set; }
    }
}
