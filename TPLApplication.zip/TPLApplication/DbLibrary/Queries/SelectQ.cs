﻿using DbLibrary.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Db.Queries
{
    public class SelectQ
    {
        public static IQueryable<Persons> SelectQPersons(TplDBContext context, int? id, string name, string surnamename, int? identity, ref string errorMessage)
        {
            IQueryable<Persons> result = null;

            try
            {
                result = context.Persons;
                if (id != null)
                {
                    result = result.Where(e => e.PersonId == id);
                }
                if (!string.IsNullOrEmpty(name))
                {
                    result = result.Where(e => e.PersonFirstName == name);
                }
                if (!string.IsNullOrEmpty(surnamename))
                {
                    result = result.Where(e => e.PersonLastName == surnamename);
                }
                if (identity != null)
                {
                    result = result.Where(e => e.PersonIdentity == identity);
                }
            }
            catch (Exception ex)
            {
                if (System.String.IsNullOrEmpty(errorMessage))
                {
                    errorMessage = "მეთოდი:  SelectQPersons()\n" + ex.Message;
                }
                else
                {
                    errorMessage = errorMessage + "\nმეთოდი:  SelectQPersons()\n" + ex.Message;
                }
            }

            return result;
        }


        public static IQueryable<Cars> SelectQCars(TplDBContext context, int? id, ref string errorMessage)
        {
            IQueryable<Cars> result = null;

            try
            {
                result = context.Cars;
                if (id != null)
                {
                    result = result.Where(e => e.CarId == id);
                }
            }
            catch (Exception ex)
            {
                if (System.String.IsNullOrEmpty(errorMessage))
                {
                    errorMessage = "მეთოდი:  SelectQCars()\n" + ex.Message;
                }
                else
                {
                    errorMessage = errorMessage + "\nმეთოდი:  SelectQCars()\n" + ex.Message;
                }
            }

            return result;
        }

        public static IQueryable<CarModels> SelectQCarModels(TplDBContext context, int? id, int? companyId, ref string errorMessage)
        {
            IQueryable<CarModels> result = null;
            try
            {
                result = context.CarModels;
                if (id != null)
                {
                    result = result.Where(e => e.CarModelId == id);
                }
                if (companyId != null)
                {
                    result = result.Where(e => e.CarManufactureId == companyId);
                }
            }
            catch (Exception ex)
            {
                if (System.String.IsNullOrEmpty(errorMessage))
                {
                    errorMessage = "მეთოდი:  SelectQCarModels()\n" + ex.Message;
                }
                else
                {
                    errorMessage = errorMessage + "\nმეთოდი:  SelectQCarModels()\n" + ex.Message;
                }
            }

            return result;
        }

        public static IQueryable<CarManufacturers> SelectQCarManufacturers(TplDBContext context, int? id, ref string errorMessage)
        {
            IQueryable<CarManufacturers> result = null;
            try
            {
                result = context.CarManufacturers;
                if (id != null)
                {
                    result = result.Where(e => e.CarManufacturerId == id);
                }
            }
            catch (Exception ex)
            {
                if (System.String.IsNullOrEmpty(errorMessage))
                {
                    errorMessage = "მეთოდი:  SelectQCarManufacturers()\n" + ex.Message;
                }
                else
                {
                    errorMessage = errorMessage + "\nმეთოდი:  SelectQCarManufacturers()\n" + ex.Message;
                }
            }

            return result;
        }

        public static IQueryable<Statuses> SelectQStatuses(TplDBContext context, int? id, ref string errorMessage)
        {
            IQueryable<Statuses> result = null;

            try
            {
                result = context.Statuses;
                if (id != null)
                {
                    result = result.Where(e => e.StatusId == id);
                }
            }
            catch (Exception ex)
            {
                if (System.String.IsNullOrEmpty(errorMessage))
                {
                    errorMessage = "მეთოდი:  SelectQStatuses()\n" + ex.Message;
                }
                else
                {
                    errorMessage = errorMessage + "\nმეთოდი:  SelectQStatuses()\n" + ex.Message;
                }
            }

            return result;
        }

        public static IQueryable<Limits> SelectQLimits(TplDBContext context, int? id, int? companyId, ref string errorMessage)
        {
            IQueryable<Limits> result = null;

            try
            {
                result = context.Limits;
                if (id != null)
                {
                    result = result.Where(e => e.LimitId == id);
                }
                if (companyId != null)
                {
                    result = result.Where(e => e.LimitCompanyId == companyId);
                }
            }
            catch (Exception ex)
            {
                if (System.String.IsNullOrEmpty(errorMessage))
                {
                    errorMessage = "მეთოდი:  SelectQLimits()\n" + ex.Message;
                }
                else
                {
                    errorMessage = errorMessage + "\nმეთოდი:  SelectQLimits()\n" + ex.Message;
                }
            }
            return result;
        }

        public static IQueryable<Tpls> SelectQTPL(TplDBContext context, int? id,  ref string errorMessage)
        {
            IQueryable<Tpls> result = null;

            try
            {
                result = context.Tpls;
                if (id != null)
                {
                    result = result.Where(e => e.TplId == id);
                }
            }
            catch (Exception ex)
            {
                if (System.String.IsNullOrEmpty(errorMessage))
                {
                    errorMessage = "მეთოდი:  SelectQTPL()\n" + ex.Message;
                }
                else
                {
                    errorMessage = errorMessage + "\nმეთოდი:  SelectQTPL()\n" + ex.Message;
                }
            }
            return result;
        }
    }
}
