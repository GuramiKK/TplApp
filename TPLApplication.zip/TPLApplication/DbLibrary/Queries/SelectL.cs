﻿using DbLibrary.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Db.Queries
{
    public class SelectL
    {

        public static List<DbLibrary.Models.XModels.Car> GetCarModel(ref string errorMessage)
        {
            List<DbLibrary.Models.XModels.Car> result = null;
            

            var cars = Db.Queries.SelectL.SelectCars(null, ref errorMessage);
            var model = Db.Queries.SelectL.SelectCarModels(null,null, ref errorMessage);
            var manufacture = Db.Queries.SelectL.SelectCarManufacturers(null, ref errorMessage);


            result = (from cr in cars
                      join mod in model on cr.CarModelId equals mod.CarModelId
                      join man in manufacture on mod.CarManufactureId equals man.CarManufacturerId
                      select new DbLibrary.Models.XModels.Car
                      {
                          CarManufactureId = man.CarManufacturerId,
                          CarModelId = mod.CarModelId,
                          CarDate = cr.CarDate,
                          CarId = cr.CarId,
                          CarManufacturerName = man.CarManufacturerName,
                          CarModelName = mod.CarModelName,
                          CarRegistyNumber = cr.CarRegistyNumber
                      }).ToList();

            return result;
        }


        public static List<DbLibrary.Models.XModels.TplModel> GetTplModel(int? companyId,int? userId, string name, string surname, int? identity, ref string errorMessage)
        {
            List<DbLibrary.Models.XModels.TplModel> result = null;

            

            var cars = GetCarModel(ref errorMessage);
            var person = SelectPersons(userId, name, surname, identity, ref errorMessage);
            var status = SelectStatuses(null, ref errorMessage);
            var limit = SelectLimits(null, companyId, ref errorMessage);

            using (TplDBContext context = new TplDBContext())
            {
                result = ((from per in person
                           join tp in context.Tpls on per.PersonId equals tp.PersonId
                           join car in cars on tp.CarId equals car.CarId
                           join stat in status on tp.StatusId equals stat.StatusId
                           join lim in limit on tp.TplLimitId equals lim.LimitId
                           select new DbLibrary.Models.XModels.TplModel
                           {
                               CarManufactureId = car.CarManufactureId,
                               CarModelId = car.CarModelId,
                               CarDate = car.CarDate,
                               CarId = car.CarId,
                               CarManufacturerName = car.CarManufacturerName,
                               CarModelName = car.CarModelName,
                               CarRegistyNumber = car.CarRegistyNumber,
                               TplLimitId = tp.TplLimitId,
                               CompanyId = (int)companyId,
                               LimitCount = lim.LimitCount,
                               LimitPremium = lim.LimitPremium,
                               PersonBirthDate = per.PersonBirthDate,
                               PersonFirstName = per.PersonFirstName,
                               PersonId = per.PersonId,
                               PersonIdentity = per.PersonIdentity,
                               PersonLastName = per.PersonLastName,
                               PersonMailAddress = per.PersonMailAddress,
                               PersonPhone = per.PersonPhone,
                               StatusId = stat.StatusId,
                               StatusName = stat.StatusName,
                               TplId = tp.TplId,
                               TplPhoto = tp.TplPhoto


                           })).ToList() ;
            }
            return result;
        }



        public static List<Persons> SelectPersons(int? id, string name, string surnamename, int? identity, ref string errorMessage)
        {
            List<Persons> result = null;
            try
            {
                using (TplDBContext context = new TplDBContext())
                {
                    var selectText = SelectQ.SelectQPersons(context, id,name,surnamename,identity,  ref errorMessage);
                    result = selectText.ToList();
                }
            }
            catch (Exception ex)
            {
                if (System.String.IsNullOrEmpty(errorMessage))
                {
                    errorMessage = "მეთოდი: SelectPersons()\n" + ex.Message;
                }
                else
                {
                    errorMessage = errorMessage + "\nმეთოდი: SelectPersons()\n" + ex.Message;
                }
            }
            return result;
        }


        public static List<Cars> SelectCars(int? id, ref string errorMessage)
        {
            List<Cars> result = null;
            try
            {
                using (TplDBContext context = new TplDBContext())
                {
                    var selectText = SelectQ.SelectQCars(context, id, ref errorMessage);
                    result = selectText.ToList();
                }
            }
            catch (Exception ex)
            {
                if (System.String.IsNullOrEmpty(errorMessage))
                {
                    errorMessage = "მეთოდი: SelectCars()\n" + ex.ToString();
                }
                else
                {
                    errorMessage = errorMessage + "\nმეთოდი: SelectCars()\n" + ex.Message;
                }
            }
            return result;
        }

        public static List<CarModels> SelectCarModels(int? id, int? companyId, ref string errorMessage)
        {
            List<CarModels> result = null;
            try
            {
                using (TplDBContext context = new TplDBContext())
                {
                    var selectText = SelectQ.SelectQCarModels(context, id, companyId, ref errorMessage);
                    result = selectText.ToList();
                }
            }
            catch (Exception ex)
            {
                if (System.String.IsNullOrEmpty(errorMessage))
                {
                    errorMessage = "მეთოდი: SelectCarModels()\n" + ex.Message;
                }
                else
                {
                    errorMessage = errorMessage + "\nმეთოდი: SelectCarModels()\n" + ex.Message;
                }
            }
            return result;
        }

        public static List<CarManufacturers> SelectCarManufacturers(int? id, ref string errorMessage)
        {
            List<CarManufacturers> result = null;
            try
            {
                using (TplDBContext context = new TplDBContext())
                {
                    var selectText = SelectQ.SelectQCarManufacturers(context, id, ref errorMessage);
                    result = selectText.ToList();
                }
            }
            catch (Exception ex)
            {
                if (System.String.IsNullOrEmpty(errorMessage))
                {
                    errorMessage = "მეთოდი: SelectCarManufacturers()\n" + ex.Message;
                }
                else
                {
                    errorMessage = errorMessage + "\nმეთოდი: SelectCarManufacturers()\n" + ex.Message;
                }
            }
            return result;
        }


        public static List<Statuses> SelectStatuses(int? id, ref string errorMessage)
        {
            List<Statuses> result = null;
            try
            {
                using (TplDBContext context = new TplDBContext())
                {
                    var selectText = SelectQ.SelectQStatuses(context, id, ref errorMessage);
                    result = selectText.ToList();
                }
            }
            catch (Exception ex)
            {
                if (System.String.IsNullOrEmpty(errorMessage))
                {
                    errorMessage = "მეთოდი: SelectStatuses()\n" + ex.Message;
                }
                else
                {
                    errorMessage = errorMessage + "\nმეთოდი: SelectStatuses()\n" + ex.Message;
                }
            }
            return result;
        }

        public static List<Limits> SelectLimits(int? id, int? companyId, ref string errorMessage)
        {
            List<Limits> result = null;
            try
            {
                using (TplDBContext context = new TplDBContext())
                {
                    var selectText = SelectQ.SelectQLimits(context, id, companyId, ref errorMessage);
                    result = selectText.ToList();
                }
            }
            catch (Exception ex)
            {
                if (System.String.IsNullOrEmpty(errorMessage))
                {
                    errorMessage = "მეთოდი: SelectLimits()\n" + ex.Message;
                }
                else
                {
                    errorMessage = errorMessage + "\nმეთოდი: SelectLimits()\n" + ex.Message;
                }
            }
            return result;
        }

        public static List<Tpls> SelectTpl(int? id,  ref string errorMessage)
        {
            List<Tpls> result = null;
            try
            {
                using (TplDBContext context = new TplDBContext())
                {
                    var selectText = SelectQ.SelectQTPL(context, id, ref errorMessage);
                    result = selectText.ToList();
                }
            }
            catch (Exception ex)
            {
                if (System.String.IsNullOrEmpty(errorMessage))
                {
                    errorMessage = "მეთოდი: SelectTpl()\n" + ex.Message;
                }
                else
                {
                    errorMessage = errorMessage + "\nმეთოდი: SelectTpl()\n" + ex.Message;
                }
            }
            return result;
        }
    }
}
