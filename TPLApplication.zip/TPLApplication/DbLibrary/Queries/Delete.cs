﻿using DbLibrary.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Transactions;

namespace Db.Queries
{
    public class Delete
    {
        public static void DeleteTpl(long Id, ref string errorMessage)
        {
            try
            {
                using (TplDBContext context = new TplDBContext())
                {
                    using (var dbTran = new TransactionScope(TransactionScopeOption.RequiresNew))
                    {
                        var obj = context.Tpls.Where(e => e.TplId == Id).FirstOrDefault();
                        context.Tpls.RemoveRange(context.Tpls.Where(rp => rp.TplId == Id));
                        context.Persons.RemoveRange(context.Persons.Where(rp => rp.PersonId == obj.PersonId));
                        context.Cars.RemoveRange(context.Cars.Where(rp => rp.CarId == obj.CarId));
                        context.SaveChanges();
                        context.SaveChanges();

                        //commit transaction  
                        dbTran.Complete();

                        if (!string.IsNullOrEmpty(errorMessage))
                        {
                            
                            dbTran.Dispose();
                            
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                if (System.String.IsNullOrEmpty(errorMessage))
                {
                    errorMessage = "ჩანაწერის წაშლა ვერ მოხერხდა: DeleteTpl()\n" + ex.Message;
                }
                else
                {
                    errorMessage = errorMessage + "\nჩანაწერის წაშლა ვერ მოხერხდა: DeleteTpl()\n" + ex.Message;
                }
            }
        }
    }
}
