﻿using DbLibrary.Models;
using DbLibrary.Models.XModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Transactions;

namespace Db.Queries
{
    public class Update
    {
        public static void UpdatePerson(Persons personeObj, ref string errorMessage)
        {
            try
            {
                using (TplDBContext context = new TplDBContext())
                {
                    Persons CheckExist = SelectL.SelectPersons((int)personeObj.PersonId,null,null, 0, ref errorMessage).FirstOrDefault();

                    if (CheckExist != null)
                    {
                        CheckExist.PersonId = personeObj.PersonId;
                        CheckExist.PersonFirstName = personeObj.PersonFirstName;
                        CheckExist.PersonBirthDate = personeObj.PersonBirthDate;
                        CheckExist.PersonIdentity = personeObj.PersonIdentity;
                        CheckExist.PersonLastName = personeObj.PersonLastName;
                        CheckExist.PersonMailAddress = personeObj.PersonMailAddress;
                        CheckExist.PersonPhone = personeObj.PersonPhone;
                        context.SaveChanges();
                    }
                    else
                    {
                        errorMessage = "ჩანაწერის ვერ მოიძებნა UpdatePerson() ";
                    }
                }
            }
            catch (Exception ex)
            {
                if (System.String.IsNullOrEmpty(errorMessage))
                {
                    errorMessage = "ჩანაწერის წაშლა ვერ განახლდა: UpdatePerson()\n" + ex.Message;
                }
                else
                {
                    errorMessage = errorMessage + "\n ჩანაწერის განახლება ვერ მოხერხდა: UpdatePerson()\n" + ex.Message;
                }
            }
        }

        public static void UpdateCar(Cars CarObj, ref string errorMessage)
        {
            try
            {
                using (TplDBContext context = new TplDBContext())
                {
                    Cars CheckExist = SelectL.SelectCars((int)CarObj.CarId, ref errorMessage).FirstOrDefault();

                    if (CheckExist != null)
                    {
                        CheckExist.CarId = CarObj.CarId;
                        CheckExist.CarModelId = CarObj.CarModelId;
                        CheckExist.CarDate = CarObj.CarDate;
                        CheckExist.CarRegistyNumber = CarObj.CarRegistyNumber;
                        context.SaveChanges();
                    }
                    else
                    {
                        errorMessage = "ჩანაწერის ვერ მოიძებნა UpdateCar() ";
                    }
                }
            }
            catch (Exception ex)
            {
                if (System.String.IsNullOrEmpty(errorMessage))
                {
                    errorMessage = "ჩანაწერის წაშლა ვერ განახლდა: UpdateCar()\n" + ex.Message;
                }
                else
                {
                    errorMessage = errorMessage + "\n ჩანაწერის განახლება ვერ მოხერხდა: UpdatePerson()\n" + ex.Message;
                }
            }
        }


        public static void UpdateCarModels(CarModels CarObj, ref string errorMessage)
        {
            try
            {
                using (TplDBContext context = new TplDBContext())
                {
                    CarModels CheckExist = SelectL.SelectCarModels((int)CarObj.CarModelId,null, ref errorMessage).FirstOrDefault();

                    if (CheckExist != null)
                    {
                        CheckExist.CarModelId = CarObj.CarModelId;
                        CheckExist.CarManufactureId = CarObj.CarManufactureId;
                        CheckExist.CarModelName = CarObj.CarModelName;
                        context.SaveChanges();
                    }
                    else
                    {
                        errorMessage = "ჩანაწერის ვერ მოიძებნა UpdateCarModels() ";
                    }
                }
            }
            catch (Exception ex)
            {
                if (System.String.IsNullOrEmpty(errorMessage))
                {
                    errorMessage = "ჩანაწერის წაშლა ვერ განახლდა: UpdateCarModels()\n" + ex.Message;
                }
                else
                {
                    errorMessage = errorMessage + "\n ჩანაწერის განახლება ვერ მოხერხდა: UpdateCarModels()\n" + ex.Message;
                }
            }
        }


        public static void UpdateCarManufacturers(CarManufacturers CarObj, ref string errorMessage)
        {
            try
            {
                using (TplDBContext context = new TplDBContext())
                {
                    CarManufacturers CheckExist = SelectL.SelectCarManufacturers((int)CarObj.CarManufacturerId, ref errorMessage).FirstOrDefault();

                    if (CheckExist != null)
                    {
                        CheckExist.CarManufacturerId = CarObj.CarManufacturerId;
                        CheckExist.CarManufacturerName = CarObj.CarManufacturerName;
                        context.SaveChanges();
                    }
                    else
                    {
                        errorMessage = "ჩანაწერის ვერ მოიძებნა UpdateCarManufacturers() ";
                    }
                }
            }
            catch (Exception ex)
            {
                if (System.String.IsNullOrEmpty(errorMessage))
                {
                    errorMessage = "ჩანაწერის წაშლა ვერ განახლდა: UpdateCarManufacturers()\n" + ex.Message;
                }
                else
                {
                    errorMessage = errorMessage + "\n ჩანაწერის განახლება ვერ მოხერხდა: UpdateCarManufacturers()\n" + ex.Message;
                }
            }
        }


        public static void UpdateTpl(Tpls obj, ref string errorMessage)
        {
            try
            {
                using (TplDBContext context = new TplDBContext())
                {
                    Tpls CheckExist = SelectL.SelectTpl((int)obj.TplId, ref errorMessage).FirstOrDefault();

                    if (CheckExist != null)
                    {
                        CheckExist.TplId = obj.TplId;
                        CheckExist.TplLimitId = obj.TplLimitId;
                        CheckExist.TplPhoto = obj.TplPhoto;
                        CheckExist.StatusId = obj.StatusId;
                        CheckExist.PersonId = obj.PersonId;
                        CheckExist.CompanyId = obj.CompanyId;
                        CheckExist.CarId = obj.CarId;
                        context.SaveChanges();
                    }
                    else
                    {
                        errorMessage = "ჩანაწერის ვერ მოიძებნა UpdateCarManufacturers() ";
                    }
                }
            }
            catch (Exception ex)
            {
                if (System.String.IsNullOrEmpty(errorMessage))
                {
                    errorMessage = "ჩანაწერის წაშლა ვერ განახლდა: UpdateCarManufacturers()\n" + ex.Message;
                }
                else
                {
                    errorMessage = errorMessage + "\n ჩანაწერის განახლება ვერ მოხერხდა: UpdateCarManufacturers()\n" + ex.Message;
                }
            }
        }


        public static void UpdateTPLModel(TplModel TPL, ref String errorMessage)
        {
            try
            {
                if (TPL != null)
                {
                    using (TplDBContext context = new TplDBContext())
                    {

                        try
                        {
                            using (var txscope = new TransactionScope(TransactionScopeOption.RequiresNew))
                            {

                                var tpl = new Tpls()
                                {
                                    CarId = TPL.CarId,
                                    CompanyId = TPL.CompanyId,
                                    PersonId = TPL.PersonId,
                                    StatusId = TPL.StatusId,
                                    TplId = TPL.TplId,
                                    TplLimitId = TPL.TplLimitId,
                                    TplPhoto = TPL.TplPhoto
                                };

                                var pers = new Persons()
                                {
                                    PersonId = TPL.PersonId,
                                    PersonBirthDate = TPL.PersonBirthDate,
                                    PersonFirstName = TPL.PersonFirstName,
                                    PersonIdentity = TPL.PersonIdentity,
                                    PersonLastName = TPL.PersonLastName,
                                    PersonMailAddress = TPL.PersonMailAddress,
                                    PersonPhone = TPL.PersonPhone

                                };

                                var car = new Cars()
                                {
                                    CarDate = TPL.CarDate,
                                    CarId = TPL.CarId,
                                    CarModelId = TPL.CarModelId,
                                    CarRegistyNumber = TPL.CarRegistyNumber
                                };


                                Db.Queries.Update.UpdateTpl(tpl, ref errorMessage);
                                Db.Queries.Update.UpdatePerson(pers, ref errorMessage);
                                Db.Queries.Update.UpdateCar(car, ref errorMessage);

                                if (!string.IsNullOrEmpty(errorMessage))
                                {

                                    txscope.Dispose();

                                }

                                txscope.Complete();
                            }
                        }
                        catch (Exception ex)
                        {
                            throw new Exception(ex.Message);
                        }
                    }
                }
                else
                {
                    throw new Exception("მითითებული ჩანაწერი/მომხმარებელი არავალიდურია");
                }
            }
            catch (Exception ex)
            {
                if (System.String.IsNullOrEmpty(errorMessage))
                {
                    errorMessage = "UpdateTPLModel()\n" + ex.Message;
                }
                else
                {
                    errorMessage = errorMessage + "UpdateTPLModel()\n" + ex.Message;
                }
            }
        }

    }
}
