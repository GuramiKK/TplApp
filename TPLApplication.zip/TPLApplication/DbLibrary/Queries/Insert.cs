﻿using DbLibrary.Models;
using DbLibrary.Models.XModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Transactions;

namespace Db.Queries
{
    public class Insert
    {
        public static long InsertPerson(Persons Person, ref String errorMessage)
        {
            long result = 0;
            try
            {
                if (Person != null)
                {
                    using (TplDBContext context = new TplDBContext())
                    {

                            try
                            {
                                // დავამატოთ ჩანაწერი
                                context.Persons.Add(Person);
                                context.SaveChanges();
                                result = Person.PersonId;
                           }
                            catch (Exception ex)
                            {
                                throw new Exception(ex.Message);
                            }
                    }
                }
                else
                {
                    throw new Exception("მითითებული ჩანაწერი/მომხმარებელი არავალიდურია");
                }
            }
            catch (Exception ex)
            {
                if (System.String.IsNullOrEmpty(errorMessage))
                {
                    errorMessage = "InsertPerson()\n" + ex.Message;
                }
                else
                {
                    errorMessage = errorMessage + "InsertPerson()\n" + ex.Message;
                }
            }
            return result;
        }

        public static long InsertCar(Cars Car, ref String errorMessage)
        {
            long result = 0;
            try
            {
                if (Car != null)
                {
                    using (TplDBContext context = new TplDBContext())
                    {

                        try
                        {
                            // დავამატოთ ჩანაწერი
                            context.Cars.Add(Car);
                            context.SaveChanges();
                            result = Car.CarId;
                        }
                        catch (Exception ex)
                        {
                            throw new Exception(ex.Message);
                        }
                    }
                }
                else
                {
                    throw new Exception("მითითებული ჩანაწერი/მომხმარებელი არავალიდურია");
                }
            }
            catch (Exception ex)
            {
                if (System.String.IsNullOrEmpty(errorMessage))
                {
                    errorMessage = "InsertCars()\n" + ex.Message;
                }
                else
                {
                    errorMessage = errorMessage + "InsertCars()\n" + ex.Message;
                }
            }
            return result;
        }

        public static void InsertCarModel(ref CarModels CarModel, ref String errorMessage)
        {
            try
            {
                if (CarModel != null)
                {
                    using (TplDBContext context = new TplDBContext())
                    {

                        try
                        {
                            // დავამატოთ ჩანაწერი
                            context.CarModels.Add(CarModel);
                            context.SaveChanges();
                        }
                        catch (Exception ex)
                        {
                            throw new Exception(ex.Message);
                        }
                    }
                }
                else
                {
                    throw new Exception("მითითებული ჩანაწერი/მომხმარებელი არავალიდურია");
                }
            }
            catch (Exception ex)
            {
                if (System.String.IsNullOrEmpty(errorMessage))
                {
                    errorMessage = "InsertCarModels()\n" + ex.Message;
                }
                else
                {
                    errorMessage = errorMessage + "InsertCarModels()\n" + ex.Message;
                }
            }
        }

        public static void InsertCarManufacturer(CarManufacturers CarManufacturer, ref String errorMessage)
        {
            try
            {
                if (CarManufacturer != null)
                {
                    using (TplDBContext context = new TplDBContext())
                    {

                        try
                        {
                            // დავამატოთ ჩანაწერი
                            context.CarManufacturers.Add(CarManufacturer);
                            context.SaveChanges();
                        }
                        catch (Exception ex)
                        {
                            throw new Exception(ex.Message);
                        }
                    }
                }
                else
                {
                    throw new Exception("მითითებული ჩანაწერი/მომხმარებელი არავალიდურია");
                }
            }
            catch (Exception ex)
            {
                if (System.String.IsNullOrEmpty(errorMessage))
                {
                    errorMessage = "InsertCarManufacturers()\n" + ex.Message;
                }
                else
                {
                    errorMessage = errorMessage + "InsertCarManufacturers()\n" + ex.Message;
                }
            }
        }

        public static void InsertTPL(Tpls TPL, ref String errorMessage)
        {
            try
            {
                if (TPL != null)
                {
                    using (TplDBContext context = new TplDBContext())
                    {

                        try
                        {
                            // დავამატოთ ჩანაწერი
                            context.Tpls.Add(TPL);
                            context.SaveChanges();
                        }
                        catch (Exception ex)
                        {
                            throw new Exception(ex.Message);
                        }
                    }
                }
                else
                {
                    throw new Exception("მითითებული ჩანაწერი/მომხმარებელი არავალიდურია");
                }
            }
            catch (Exception ex)
            {
                if (System.String.IsNullOrEmpty(errorMessage))
                {
                    errorMessage = "InsertTPLs()\n" + ex.Message;
                }
                else
                {
                    errorMessage = errorMessage + "InsertTPLs()\n" + ex.Message;
                }
            }
        }



        public static void InsertTPLModel(TplModel TPL, ref String errorMessage)
        {
            try
            {
                if (TPL != null)
                {
                    using (TplDBContext context = new TplDBContext())
                    {

                        try
                        {
                            using (var txscope = new TransactionScope(TransactionScopeOption.RequiresNew))
                            {



                                var pers = new Persons()
                                {
                                    PersonId = TPL.PersonId,
                                    PersonBirthDate = TPL.PersonBirthDate,
                                    PersonFirstName = TPL.PersonFirstName,
                                    PersonIdentity = TPL.PersonIdentity,
                                    PersonLastName = TPL.PersonLastName,
                                    PersonMailAddress = TPL.PersonMailAddress,
                                    PersonPhone = TPL.PersonPhone

                                };

                                var car = new Cars()
                                {
                                    CarDate = TPL.CarDate,
                                    CarModelId = TPL.CarModelId,
                                    CarRegistyNumber = TPL.CarRegistyNumber                                
                                };


                                
                                long per = Db.Queries.Insert.InsertPerson(pers, ref errorMessage);
                                long cr = Db.Queries.Insert.InsertCar(car, ref errorMessage);


                                var tpl = new Tpls()
                                {
                                    CarId = cr,
                                    CompanyId = 1,
                                    PersonId = per,
                                    StatusId = 1,
                                    TplLimitId = TPL.TplLimitId,
                                    TplPhoto = TPL.TplPhoto
                                };

                                Db.Queries.Insert.InsertTPL(tpl, ref errorMessage);

                                if (!string.IsNullOrEmpty(errorMessage))
                                {
                                    
                                    txscope.Dispose();
                                    
                                }

                                txscope.Complete();
                            }
                        }
                        catch (Exception ex)
                        {
                            throw new Exception(ex.Message);
                        }
                    }
                }
                else
                {
                    throw new Exception("მითითებული ჩანაწერი/მომხმარებელი არავალიდურია");
                }
            }
            catch (Exception ex)
            {
                if (System.String.IsNullOrEmpty(errorMessage))
                {
                    errorMessage = "InsertTPLModel()\n" + ex.Message;
                }
                else
                {
                    errorMessage = errorMessage + "InsertTPLModel()\n" + ex.Message;
                }
            }
        }

    }
}
