﻿using Microsoft.Win32;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace DesctopApp
{
    /// <summary>
    /// Interaction logic for EditWindow.xaml
    /// </summary>
    public partial class EditWindow : Window
    {
        #region Private Members
        private string _formTitle;

        private DataChangeType _dataChangeType; // ოპერაციის კოდი: 1-დამატება, 2-რედაქტირება, 3-წაშლა
        private ActionMode _actionMode;         // სამუშაო რეჟიმი: 1-რედაქტირებული მონაცემების დაბრუნება ბაზაში გადაწერის გარეშე,
        //                                                          2-რედაქტირებული მონაცემების დაბრუნება ბაზაში გადაწერით
        private long _userId;
        private DbLibrary.Models.XModels.TplModel _per;
        private ToolTip _toolTip;
        private bool _formCloseSwitch;
        #endregion
        static HttpClient client = new HttpClient();

        #region Constructors
        public EditWindow(DataChangeType DataChangeType, ActionMode ActionMode, long UserId)
        {
            InitializeComponent();

            this._dataChangeType = DataChangeType;
            this._actionMode = ActionMode;
            this._userId = UserId;
            this._per = new DbLibrary.Models.XModels.TplModel();
            this._formCloseSwitch = true;
        }

        public EditWindow(DataChangeType DataChangeType, ActionMode ActionMode, long UserId, DbLibrary.Models.XModels.TplModel tpl)
        {
            InitializeComponent();

            this._dataChangeType = DataChangeType;
            this._actionMode = ActionMode;
            this._userId = UserId;
            this._per = (tpl != null) ? tpl : new DbLibrary.Models.XModels.TplModel();
            this._formCloseSwitch = true;
            EmployeeEditForm_Load(null, null);
        }
        #endregion

        #region Public Properties
        public DbLibrary.Models.XModels.TplModel Object
        {
            get { return this._per; }
        }
        #endregion

        #region Private Methods


        private int OperateToEmployees(DataChangeType DataChangeType, ref DbLibrary.Models.XModels.TplModel tpl, ref string ErrorMessage)
        {
            int iResult = 0;

            try
            {
                ErrorMessage = System.String.Empty;


                    switch (DataChangeType)
                    {
                        case DataChangeType.Insert:
                            var json = JsonConvert.SerializeObject(tpl);
                             var stringContent = new StringContent(json,Encoding.UTF8, "application/json");
                             HttpResponseMessage response = client.PostAsync("https://localhost:44375/App", stringContent).Result;
                            if (response.IsSuccessStatusCode)
                            {
                                string result = response.Content.ReadAsStringAsync().Result;
                                model = JsonConvert.DeserializeObject<List<DbLibrary.Models.CarModels>>(result);
                            }
                            break;
                        case DataChangeType.Update:
                        var json1 = JsonConvert.SerializeObject(tpl);
                        var stringContent1 = new StringContent(json1);
                        HttpResponseMessage response1 = client.PostAsync("https://localhost:44375/App/1", stringContent1).Result;
                        if (response1.IsSuccessStatusCode)
                        {
                            string result = response1.Content.ReadAsStringAsync().Result;
                            model = JsonConvert.DeserializeObject<List<DbLibrary.Models.CarModels>>(result);
                        }
                        break;
                    case DataChangeType.Delete:
                            //EmployeeServiceClient.DeletePerson(tpl, this._userId, ref ErrorMessage);
                            break;
                        default:
                            throw new Exception("არასწორი ოპერაციის კოდი");
                    }
            }
            catch (Exception ex)
            {
                ErrorMessage = ex.Message + " Source: OperateToEmployees " + ErrorMessage;
                iResult = -1;
            }
            finally
            {
            }
            return iResult;
        }


        List<DbLibrary.Models.CarManufacturers> manuf = null;
        List<DbLibrary.Models.CarModels> model = null;
        List<DbLibrary.Models.Limits> limits = null;

        string errorMessage = null;

        private void EmployeeEditForm_Load(object sender, EventArgs e)
        {
            string pErrorMessage = System.String.Empty;


            try
            {
                /* ვაფორმირებთ ფორმის სათაურს */
                this._formTitle = "დაზღვევა";
                switch (this._dataChangeType)
                {
                    case DataChangeType.Insert:
                        this._formTitle += " [დამატება]";
                        break;
                    case DataChangeType.Update:
                        this._formTitle += " [რედაქტირება]";
                        break;

                    default:
                        break;
                }
                // ფორმის სათაური
                this.Title = this._formTitle;

                // კომენტარების დამხმარე კოდებისათვის
                this._toolTip = new ToolTip();






                /* გადაგვაქვს შემოსული ინფორმაცია კონტროლებში */
                this.EmployeeFirstNameTextBox.Text = (this._per.PersonFirstName != null) ? this._per.PersonFirstName : System.String.Empty;
                this.EmployeeLastNameTextBox.Text = (this._per.PersonLastName != null) ? this._per.PersonLastName : System.String.Empty;
                this.EmployeeIdentityValueTextBox.Text = (this._per.PersonIdentity !=0 ) ? this._per.PersonIdentity.ToString() : string.Empty;

                this.EmployeeBirthDateValueDateTimePicker.SelectedDate = ((this._per.PersonBirthDate != null) && (this._per.PersonBirthDate != System.DateTime.MinValue)) ? (DateTime)this._per.PersonBirthDate : this.EmployeeBirthDateValueDateTimePicker.SelectedDate;

                this.PhoneValueTextBox.Text = (this._per.PersonPhone != 0) ? this._per.PersonPhone.ToString() : System.String.Empty;
                this.MailValueTextBox.Text = (this._per.PersonMailAddress != null) ? this._per.PersonMailAddress : System.String.Empty;
                this.CarNumValueTextBox.Text = (this._per.CarRegistyNumber != null) ? this._per.CarRegistyNumber : System.String.Empty;
                // ამოვიღოთ საცნობარო მონაცემები კომბოების შესავსებად


                HttpResponseMessage response = client.GetAsync("https://localhost:44375/App/model/" + _per.CarManufactureId).Result;
                if (response.IsSuccessStatusCode)
                {
                    string result = response.Content.ReadAsStringAsync().Result;
                    model = JsonConvert.DeserializeObject<List<DbLibrary.Models.CarModels>>(result);
                }

                HttpResponseMessage response2 = client.GetAsync("https://localhost:44375/App/limit/1").Result;
                if (response2.IsSuccessStatusCode)
                {
                    string result = response2.Content.ReadAsStringAsync().Result;
                    limits = JsonConvert.DeserializeObject<List<DbLibrary.Models.Limits>>(result);
                }

                HttpResponseMessage response3 = client.GetAsync("https://localhost:44375/App/manufacturer").Result;
                if (response3.IsSuccessStatusCode)
                {
                    string result = response3.Content.ReadAsStringAsync().Result;
                    manuf = JsonConvert.DeserializeObject<List<DbLibrary.Models.CarManufacturers>>(result);
                }


                var limitModel = from lm in limits
                                 select new DbLibrary.Models.XModels.LimitModel
                                 {
                                     LimitCompanyId = lm.LimitCompanyId,
                                     LimitCount = lm.LimitCount,
                                     LimitPremium = lm.LimitPremium,
                                     LimitId = lm.LimitId,
                                     name = lm.LimitCount.ToString() + "/" + lm.LimitPremium.ToString()

                                 };

                //limits
                this.LimitValueComboBox.ItemsSource = limitModel;
                this.LimitValueComboBox.DisplayMemberPath = "name";
                this.LimitValueComboBox.SelectedValuePath = "LimitId";
                this.LimitValueComboBox.SelectedIndex = -1;

                if ((this.LimitValueComboBox.Items.Count > 0) && (this._per.TplLimitId != 0))
                    foreach (DbLibrary.Models.Limits lim in this.LimitValueComboBox.Items)
                        if ((long)lim.LimitId == this._per.TplLimitId)
                        {
                            this.LimitValueComboBox.SelectedIndex = this.LimitValueComboBox.Items.IndexOf(lim);
                            break;
                        }


                // model
                this.ModelValueComboBox.ItemsSource = model;
                this.ModelValueComboBox.DisplayMemberPath = "CarModelName";
                this.ModelValueComboBox.SelectedValuePath = "CarModelId";
                this.ModelValueComboBox.SelectedIndex = -1;

                if ((this.ModelValueComboBox.Items.Count > 0))
                    foreach (DbLibrary.Models.CarModels cm in this.ModelValueComboBox.Items)
                        if ((long)cm.CarModelId == this._per.CarModelId)
                        {
                            this.ModelValueComboBox.SelectedIndex = this.ModelValueComboBox.Items.IndexOf(cm);
                            break;
                        }

                ///manufacturer
                this.ManufacturerComboBox.ItemsSource = manuf;
                this.ManufacturerComboBox.DisplayMemberPath = "CarManufacturerName";
                this.ManufacturerComboBox.SelectedValuePath = "CarManufacturerId";
                this.ManufacturerComboBox.SelectedIndex = -1;

                if ((this.ManufacturerComboBox.Items.Count > 0))
                    foreach (DbLibrary.Models.CarManufacturers cs in this.ManufacturerComboBox.Items)
                        if (cs.CarManufacturerId == this._per.CarManufactureId)
                        {
                            this.ManufacturerComboBox.SelectedIndex = this.ManufacturerComboBox.Items.IndexOf(cs);
                            break;
                        }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, " Source: EditForm_Load");
            }
            finally
            {
            }
        }


        public DbLibrary.Models.XModels.TplModel pEmployee = null;

        bool IsValidEmail(string email)
        {
            try
            {
                var addr = new System.Net.Mail.MailAddress(email);
                return addr.Address == email;
            }
            catch
            {
                return false;
            }
        }

        private void CommitButton_Click(object sender, EventArgs e)
        {

            string pErrorMessage = System.String.Empty;
            int iResult = 0;

            try
            {
                /* ფორმის დახურვის ნებართვა */
                this._formCloseSwitch = false;

                if(EmployeeIdentityValueTextBox.Text.Trim().Length != 11)
                {
                    MessageBox.Show("იდი უნდა იყოს 11 ციფრიანი");
                    return;
                }
                if ((DateTime)this.EmployeeBirthDateValueDateTimePicker.SelectedDate > DateTime.Now.AddYears(-18))
                {
                    MessageBox.Show("ასაკი უნდა იყოს 18 წელზე ზე მეტი");
                    return;
                }
                if (!IsValidEmail(MailValueTextBox.Text.Trim()))
                {
                    MessageBox.Show("მაილი არავალიდული");
                    return;
                }



                /* ფორმის დახურვის ნებართვა */
                this._formCloseSwitch = true;

                pEmployee = new DbLibrary.Models.XModels.TplModel()
                {
                    TplId = this._per.TplId,
                    PersonFirstName = this.EmployeeFirstNameTextBox.Text.Trim(),
                    PersonLastName = this.EmployeeLastNameTextBox.Text.Trim(),
                    PersonIdentity = Convert.ToInt64(this.EmployeeIdentityValueTextBox.Text.Trim()),
                    PersonBirthDate = (DateTime)this.EmployeeBirthDateValueDateTimePicker.SelectedDate,
                    CarManufactureId = (this.ManufacturerComboBox.SelectedValue != null) ? System.Convert.ToInt32(this.ManufacturerComboBox.SelectedValue) : (long)0,
                    CarDate = (DateTime)this.CarDateValueDateTimePicker.SelectedDate,
                    CarModelId = (this.ModelValueComboBox.SelectedValue != null) ? System.Convert.ToInt32(this.ModelValueComboBox.SelectedValue) : (long)0,
                    CarRegistyNumber = this.CarNumValueTextBox.Text.Trim(),
                    PersonMailAddress = this.MailValueTextBox.Text.Trim(),
                    PersonPhone = Convert.ToInt64(this.PhoneValueTextBox.Text.Trim()),
                    TplLimitId = (this.LimitValueComboBox.SelectedValue != null) ? System.Convert.ToInt32(this.LimitValueComboBox.SelectedValue) : (long)0,
                    TplPhoto = data
                };
                DbLibrary.Models.XModels.TplModel ha = pEmployee;
                DbLibrary.Models.XModels.TplModel hu = pEmployee;


                switch (this._actionMode)
                {
                    case ActionMode.ReturnDataOnly: /* რედაქტირებული მონაცემების დაბრუნება ბაზაში გადაწერის გარეშე */
                        break;
                    case ActionMode.WriteAndReturnData: /* რედაქტირებული მონაცემების დაბრუნება ბაზაში გადაწერით */
                        iResult = OperateToEmployees(this._dataChangeType, ref pEmployee, ref pErrorMessage);
                        break;
                    default:
                        break;
                }

                if (iResult == 0)
                {
                    /* წარმატება */
                    this._per = pEmployee;
                    this.DialogResult = DialogResult;
                }
                else
                {
                    throw new Exception("ოპერაცია წარუმატებლად დასრულდა\n" + pErrorMessage);
                }
                this.Close();
            }
            catch (Exception ex)
            {
                /* ვაუქმებთ ოპერაციას და ვკრძალავთ ფორმის დახურვას */
                this._formCloseSwitch = false;
                MessageBox.Show(ex.Message, " Source: CommitButton_Click");
                this.DialogResult = DialogResult;
            }
            finally
            {

            }
        }

        private void RollbackButton_Click(object sender, EventArgs e)
        {
            try
            {
                // ჩავრთოთ ფორმის დახურვის ნებართვა და გავიდეთ ფორმიდან
                this._formCloseSwitch = true;
                this.DialogResult = DialogResult;
                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, " Source: RollbackButton_Click");
            }
            finally
            {
            }
        }

        private void EmployeeEditForm_FormClosing(object sender, CancelEventArgs e)
        {
            try
            {
                e.Cancel = !this._formCloseSwitch;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, " Source: EmployeeEditForm_FormClosing");
            }
            finally
            {
            }
        }

        #endregion
        byte[] data;
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog op = new OpenFileDialog();
            op.Title = "Select a picture";
            op.Filter = "All supported graphics|*.jpg;*.jpeg;*.png|" +
              "JPEG (*.jpg;*.jpeg)|*.jpg;*.jpeg|" +
              "Portable Network Graphic (*.png)|*.png";
            if (op.ShowDialog() == true)
            {
                var test = new BitmapImage(new Uri(op.FileName));
                

                
                JpegBitmapEncoder encoder = new JpegBitmapEncoder();
                encoder.Frames.Add(BitmapFrame.Create(test));
                using (MemoryStream ms = new MemoryStream())
                {
                    encoder.Save(ms);
                    data = ms.ToArray();
                }

                if(data.Length > 2000000)
                {
                    MessageBox.Show("ფოტო 2 მბ ზე დიდია");
                    data = null;
                }
                    
            }
        }


    }
}
