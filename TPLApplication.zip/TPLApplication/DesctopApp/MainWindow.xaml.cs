﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace DesctopApp
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    /// 


        public partial class MainWindow : Window
        {
        static HttpClient client = new HttpClient();

        private long _employeeIdToFind = 0;
        private bool _isUser;
        private string _employeeIdentityToFind = null;
        private DbLibrary.Models.XModels.TplModel _personData;


        private long _personPostDataGridViewPersonPostId = 0;


        private long _currentEmployeeId;

        private long _id;

        DbLibrary.Models.XModels.TplModel test = new DbLibrary.Models.XModels.TplModel();


        public MainWindow()
        {
            InitializeComponent();
        }

        private void MainFiltersViewDataButton_Click(object sender, EventArgs e)
        {
            try
            {
                ClearData();
                this.FillEmployeeFindTabPageXData();
                // დავცალოთ ფილტრაციის პანელი
                this.ClearFindPanel();
                /* გავააქტიუროთ ცხრილი */
                if ((this.MainFindResultsDataGridView.Items.Count > 0))
                    this.MainFindResultsDataGridView.Focus();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, " Source: MainFiltersViewDataButton_Click");
            }
            finally
            {
            }
        }

        private void FillEmployeeFindTabPageXData()
        {
            List<DbLibrary.Models.XModels.TplModel> ShortData = null;
            bool filter = false;

            try
            {

                /* დავცალოთ მთავარი ცხრილი */
                this.MainFindResultsDataGridView.ItemsSource = null;
                this.MainFindResultsDataGridView.AutoGenerateColumns = false;

                // მონაცემების მოძიების აუცილებლობის განსაზღვრა
                filter = ((this.EmployeeIdentityValueTextBox.Text.Trim().Length > 0) ||
                         (this.MainEmployeeFirstNameValueTextBox.Text.Trim().Length > 0) ||
                         (this.MainEmployeeLastNameValueTextBox.Text.Trim().Length > 0) /*||*/
                         /*(this.PersonPostPostValueComboBox.Text.Trim().Length > 0)*/);

                var name = MainEmployeeFirstNameValueTextBox.Text.Trim().ToString();
                var surname = MainEmployeeLastNameValueTextBox.Text.Trim().ToString();
                var Identity = EmployeeIdentityValueTextBox.Text.Trim().ToString();

                if (string.IsNullOrEmpty(name))
                    name = "0";
                if (string.IsNullOrEmpty(surname))
                    surname = "0";
                if (string.IsNullOrEmpty(Identity))
                    Identity = "0";

                // ფილტრი
                if (filter)
                {
                    // გავანულოთ მიმდინარე პერსონის იდენტიფიკატორი
                    //this._currentEmployeeId = 0;
                    string errorMessage = string.Empty;
                    var juststring = "https://localhost:44375/App/1/" + name + "/" + surname + "/" + Identity;
                    HttpResponseMessage response = client.GetAsync(juststring).Result;
                    if (response.IsSuccessStatusCode)
                    {
                        string result = response.Content.ReadAsStringAsync().Result;
                        ShortData = JsonConvert.DeserializeObject<List<DbLibrary.Models.XModels.TplModel>>(result);
                    }

                    if (ShortData != null && ShortData.Count != 0)
                    {
                        this.MainFindResultsDataGridView.ItemsSource = ShortData;
                        //this._employeeIdentityToFind = ShortData.FirstOrDefault().PersonIdentity;
                    }
                    else
                    {
                        MessageBox.Show("პიროვნება ასეთი მონაცემებით ვერ მოიძებნა");
                    }
                    if (!string.IsNullOrEmpty(errorMessage))
                    {
                        MessageBox.Show(errorMessage);
                    }

                }

                // დავცალოთ ფილტრაციის პანელი
                this.ClearFindPanel();

                
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, " Source: FillEmployeeFindTabPageXData");
            }
            finally
            {
            }
        }

        // საძიებელი ტაბის საძიებელი ნაწილის კონტროლების გასუფთავება
        private void ClearFindPanel()
        {
            try
            {
                // გავასუფთაოთ საძიებელი ველები
                this.EmployeeIdentityValueTextBox.Text = System.String.Empty;
                this.MainEmployeeFirstNameValueTextBox.Text = System.String.Empty;
                this.MainEmployeeLastNameValueTextBox.Text = System.String.Empty;

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, " Source: ClearFindPanel");
            }
            finally
            {
            }
        }


        private void ClearData()
        {
            // დავცალოთ დეტალური მონაცემების პანელი
            
            this.DetailsEmployeeIdentityValueTextBox.Content = System.String.Empty;
            this.DetailsEmployeeFirstNameValueLabel.Content = System.String.Empty;
            BirthDateValueLabel.Content = string.Empty;
            DetailsEmployeeLastNameValueLabel.Content = string.Empty;
            DetailsEmployeePhoneValueLabel.Content = string.Empty;
            MailLabel.Content = string.Empty;
            DetailsManufValueLabel.Content = string.Empty;
            ModelLabel.Content = string.Empty;
            CarNumberextBox.Content = string.Empty;
            limitValueTextBox.Content = string.Empty;
            StatusValueTextBox.Content = string.Empty;
            CarDateValueTextBox.Content = string.Empty;


        }


        void b1SetColor(object sender, SelectedCellsChangedEventArgs e)
        {

            try
            {
                test = (DbLibrary.Models.XModels.TplModel)MainFindResultsDataGridView.SelectedItem;
                _id = test.PersonId;
                _currentEmployeeId = test.PersonId;
                FillDetailsTabPagePersonalData(test);
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }




        private void FillDetailsTabPagePersonalData(DbLibrary.Models.XModels.TplModel obj)
        {
            try
            {
                string errorMessage = string.Empty;




                this.ClearData();

                // შევავსოთ დეტალური მონაცემების პანელი
                if (obj != null)
                {
                    this.DetailsEmployeeIdentityValueTextBox.Content = (obj.PersonIdentity != null) ? obj.PersonIdentity.ToString() : System.String.Empty;
                    this.DetailsEmployeeFirstNameValueLabel.Content = (obj.PersonFirstName != null) ? obj.PersonFirstName.Trim() : System.String.Empty;
                    this.DetailsEmployeeLastNameValueLabel.Content = (obj.PersonLastName != null) ? obj.PersonLastName.Trim() : System.String.Empty;
                    this.BirthDateValueLabel.Content = obj.PersonBirthDate.ToString();

                    DetailsEmployeePhoneValueLabel.Content = obj.PersonPhone.ToString() ;
                    MailLabel.Content = obj.PersonMailAddress;
                    DetailsManufValueLabel.Content = obj.CarManufacturerName;
                    ModelLabel.Content = obj.CarModelName;
                    CarNumberextBox.Content = obj.CarRegistyNumber;
                    limitValueTextBox.Content = obj.LimitPremium + "/" + obj.LimitCount;
                    StatusValueTextBox.Content = obj.StatusName;
                    CarDateValueTextBox.Content = obj.CarDate;
                    PhotoLabel.Content = byteArrayToImage(obj.TplPhoto);

                    // ჩავრთოთ რედაქტირების ღილაკი
                    this.DetailsEditButton.Visibility = Visibility.Visible;



                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
            }
        }

        public Image byteArrayToImage(byte[] bytesArr)
        {
            using (MemoryStream memstr = new MemoryStream(bytesArr))
            {
                Image img = Image.FromStream(memstr);
                return img;
            }
        }
        private void DetailsEditButton_Click(object sender, EventArgs e)
        {

            try
            {
                EditWindow employeeDataEditor = new EditWindow(DataChangeType.Update, ActionMode.WriteAndReturnData, _id, test);
                employeeDataEditor.ShowDialog();
                b1SetColor(null, null);

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, " Source: DetailsEditButton_Click");
            }
            finally
            {
            }
        }




        private void NewEmployeeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            EditWindow newEmployeeForm = null;
            //VerifyPersonalNumber verifyPersonalNumber = null;
            DbLibrary.Models.XModels.TplModel Data = new DbLibrary.Models.XModels.TplModel();

            newEmployeeForm = new EditWindow(DataChangeType.Insert, ActionMode.WriteAndReturnData, 1, Data);
            newEmployeeForm.ShowDialog();



        }


    }
}
