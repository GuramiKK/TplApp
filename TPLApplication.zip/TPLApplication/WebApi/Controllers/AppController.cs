﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using DbLibrary;
using Microsoft.AspNetCore.Diagnostics;
using Serilog;
using System.Transactions;
using System.Net;

namespace WebApi.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class AppController : ControllerBase
    {
        [HttpGet("{id}")]
        public IEnumerable<DbLibrary.Models.XModels.TplModel> Get(int id)
        {

            string error = "";

            List<DbLibrary.Models.XModels.TplModel> result = Db.Queries.SelectL.GetTplModel(id,null,null,null,null, ref error);

            if (!string.IsNullOrEmpty(error))
            {
                Log.Error(error);
            }

            return result;
        }

        [HttpGet("{Id}/{name}/{surname}/{identitiy}")]
        public IEnumerable<DbLibrary.Models.XModels.TplModel> Get(int id, string name, string surname, int identitiy)
        {

            string error = "";
            int? i = null;
            if (identitiy != 0)
                i = identitiy;
            if (name == "0")
                name = null;
            if (surname == "0")
                surname = null;



            List<DbLibrary.Models.XModels.TplModel> result = Db.Queries.SelectL.GetTplModel(id, null, name, surname, i, ref error);

            if (!string.IsNullOrEmpty(error))
            {
                Log.Error(error);
            }

            return result;
        }


        [HttpGet("manufacturer")]
        public IEnumerable<DbLibrary.Models.CarManufacturers> GetMan()
        {
            string error = "";

            List<DbLibrary.Models.CarManufacturers> result = Db.Queries.SelectL.SelectCarManufacturers(null, ref error);

            if (!string.IsNullOrEmpty(error))
            {
                Log.Error(error);
            }

            return result;
        }

        [HttpGet("model/{Id}")]
        public IEnumerable<DbLibrary.Models.CarModels> GetModel(int Id)
        {
            string error = "";
            int? ini = null;
            if (Id != 0)
                ini = Id;

            List<DbLibrary.Models.CarModels> result = Db.Queries.SelectL.SelectCarModels(null, ini, ref error);

            if (!string.IsNullOrEmpty(error))
            {
                Log.Error(error);
            }

            return result;
        }

        [HttpGet("limit/{Id}")]
        public IEnumerable<DbLibrary.Models.Limits> Getlimit(int Id)
        {
            string error = "";

            List<DbLibrary.Models.Limits> result = Db.Queries.SelectL.SelectLimits(null, Id, ref error);

            if (!string.IsNullOrEmpty(error))
            {
                Log.Error(error);
            }

            return result;
        }


        [HttpPost]
        public ActionResult Post(DbLibrary.Models.XModels.TplModel tplModel)
        {
            string error = "";

            Db.Queries.Insert.InsertTPLModel(tplModel, ref error);

            if (!string.IsNullOrEmpty(error))
            {
                Log.Error(error);
                return this.StatusCode((int)HttpStatusCode.BadRequest);
            }

            return this.Ok();
        }


        [HttpPut]
        public ActionResult Put([FromBody] DbLibrary.Models.XModels.TplModel tplModel)
        {
            string error = "";

            Db.Queries.Update.UpdateTPLModel(tplModel, ref error);

            if (!string.IsNullOrEmpty(error))
            {
                Log.Error(error);
                return this.StatusCode((int)HttpStatusCode.BadRequest);
            }

            return this.Ok();
        }


        [HttpDelete("{id}")]
        public ActionResult Delete(int id)
        {
            string error = "";

            Db.Queries.Delete.DeleteTpl(id ,ref error);

            if (!string.IsNullOrEmpty(error))
            {
                Log.Error(error);
                return this.StatusCode((int)HttpStatusCode.BadRequest);
            }
            return this.Ok();
        }
    }
}
